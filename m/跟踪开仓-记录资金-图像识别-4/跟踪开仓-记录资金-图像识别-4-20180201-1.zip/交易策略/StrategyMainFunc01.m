function PosStatus = StrategyMainFunc01

% clear; close all; clc;

Fn = {'al', 'cf', 'cu', 'if' , 'j',  'l', ...
    'ma', 'p', 'rb', 'ru', 'sr', 'ta', 'y', 'zn','au','m'};

plotFlg = 0;
lenFn = length(Fn);
h = waitbar(0,'Please wait...');
steps = lenFn;
nCount = 0;
PosStatus = [];
for i = 1:lenFn   
    if strcmp(Fn{i},'au') || strcmp(Fn{i},'m')
        PosStatusTmp = StrategyFunc_DualMA([Fn{i},'888'],plotFlg);
    else
        PosStatusTmp = StrategyFunc([Fn{i},'888'],plotFlg);
        % waitbar(i / steps,h,sprintf('%s',Fn{i}));
    end
    if length(PosStatusTmp) == 4
        nCount = nCount+1;
        PosStatus(nCount).a = [Fn{i},num2str(PosStatusTmp(1))];
        PosStatus(nCount).b = PosStatusTmp(4);
    end
        
    waitbar(i / steps);
end
close(h)

end





