clear; clc; close all;

% ContractInput('Ma1701')

% aa.contract = 'v1705';
% aa.LongShort = [];
% aa.hands = [];
% done = ChiCang(aa);

% p = mfilename('fullpath') %#ok 

% figure(1);
% N = 1e4;
% x = rand(1,N);
% tic
% for i = 1:100
%     figure(1)
%     subplot(221);
%     plot(1:N,x,1:N,x);
%     drawnow;  getframe(gcf);
%     subplot(222);
%     plot(1:N,x,1:N,x);
%     drawnow;  getframe(gcf);
%     subplot(223);
%     plot(1:N,x,1:N,x);
%     drawnow;  getframe(gcf);
%     subplot(224);
%     plot(1:N,x,1:N,x);
%     drawnow;  getframe(gcf);
% end
% toc

clipboard('copy', 'L1705')
paste;





























































