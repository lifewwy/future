t = timer;
t.StartDelay = 10;
t.TimerFcn = @(myTimerObj, thisEvent)runCallbackFunc;
start(t)












